export const testIds = {
  appConfig: {
    apiKey: 'data-testid ac-api-key',
    apiUrl: 'data-testid ac-api-url',
    submit: 'data-testid ac-submit-form',
  },
  pageOne: {
    container: 'data-testid pg-one-container',
  },
  pageTwo: {
    container: 'data-testid pg-two-container',
  },
};
