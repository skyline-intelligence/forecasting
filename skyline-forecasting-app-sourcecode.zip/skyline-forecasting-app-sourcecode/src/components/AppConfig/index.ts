import AppConfig from './AppConfig';

export default AppConfig;