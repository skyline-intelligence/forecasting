import React, { useEffect, useState } from 'react';
import { testIds } from '../components/testIds';
import { PluginPage } from '@grafana/runtime';
import { lastValueFrom } from 'rxjs';
import { getBackendSrv } from '@grafana/runtime';
import { Button, Input, HorizontalGroup, VerticalGroup, Select } from '@grafana/ui';

interface MetricsData {
  metrics_name: string;
  predict_name: string;
  statement: string;
  create_time: string;
}

interface DataSourceOption {
  label: string;
  value: string;
}

function PageOne() {
  // 定义状态来存储表格数据
  const [tableData, setTableData] = useState<MetricsData[]>([]);
  // 定义加载状态
  const [isLoading, setIsLoading] = useState(true);
  // 定义是否显示添加表单
  const [showAddForm, setShowAddForm] = useState(false);
  // 定义新指标的输入值
  const [newMetricsName, setNewMetricsName] = useState('');
  const [newStatement, setNewStatement] = useState('');
  const [selectedDataSource, setSelectedDataSource] = useState<DataSourceOption | null>(null);
  const [dataSources, setDataSources] = useState<DataSourceOption[]>([]);
  // 定义提交状态
  const [isSubmitting, setIsSubmitting] = useState(false);

  // 在组件挂载时获取数据
  useEffect(() => {
    fetchData();
    fetchDataSources();
  }, []); // 空依赖数组意味着只在组件挂载时运行一次

  // 获取Grafana数据源列表
  const fetchDataSources = async () => {
    try {
      const response = getBackendSrv().fetch({
        url: 'api/datasources',
        method: 'GET',
      });

      const result = await lastValueFrom(response);
      
      if (result.status >= 400) {
        throw new Error(`获取数据源失败: ${result.statusText}`);
      }

      const sources = result.data || [];
      console.error(sources);
      const options: DataSourceOption[] = sources.map((source: any) => ({
        label: source.name,
        value: source.name,
      }));

      setDataSources(options);
      
      // 默认选择prometheus数据源（如果存在）
      const prometheusSource = options.find(option => option.value.toLowerCase().includes('prometheus'));
      if (prometheusSource) {
        setSelectedDataSource(prometheusSource);
      } else if (options.length > 0) {
        setSelectedDataSource(options[0]);
      }
    } catch (error) {
      console.error('获取数据源列表失败:', error);
    }
  };

  // 获取数据的函数
  const fetchData = async () => {
    try {
      setIsLoading(true);

      const requestBody = {
        command: 'query_grafana_metrics'
      };
      const dataProxyUrl = `api/plugin-proxy/skyline-forecasting-app/backend_service`;
      console.error("===============开始获取数据================");
      const response = getBackendSrv().fetch({
        url: dataProxyUrl,
        method: 'POST',
        data: requestBody,
      });

      const result = await lastValueFrom(response);
      
      // 检查响应状态
      if (result.status >= 400) {
        throw new Error(`HTTP error! status: ${result.status}`);
      }
      
      // 添加日志查看返回的数据结构
      console.error('API返回的数据:', result.data);
      
      // 确保数据是数组
      let data = result.data;
      if (data && typeof data === 'object' && !Array.isArray(data) && 
          data.metrics_name && data.predict_name && data.statement && data.create_time) {
        console.error('检测到特殊格式的数据，进行转换');
        
        // 获取对象的长度（假设所有属性的长度相同）
        const length = Object.keys(data.metrics_name).length;
        const transformedData: MetricsData[] = [];
        
        // 转换为数组格式
        for (let i = 0; i < length; i++) {
          transformedData.push({
            metrics_name: data.metrics_name[i],
            predict_name: data.predict_name[i],
            statement: data.statement[i],
            create_time: new Date(data.create_time[i]).toLocaleString() // 转换时间戳为可读格式
          });
        }
        
        data = transformedData;
      } else if (data && !Array.isArray(data)) {
        // 其他对象类型处理逻辑...
        if (typeof data === 'object' && data !== null) {
          console.error('API返回的数据是普通JSON对象格式');
          data = [data]; // 将单个对象转换为数组
        } else {
          console.error('API返回的数据不是JSON对象或数组格式');
          data = [];
        }
      }
      
      setTableData(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error('获取数据失败:', error);
      setTableData([]);
    } finally {
      setIsLoading(false);
    }
  };

  // 提交新指标
  const handleSubmit = async () => {
    if (!newMetricsName || !newStatement || !selectedDataSource) {
      alert('请填写完整的指标信息并选择数据源');
      return;
    }

    try {
      setIsSubmitting(true);

      const requestBody = {
        metrics_name: newMetricsName,
        statement: newStatement,
        datasource: selectedDataSource.value,
        command: 'add_metrics'
      };

      const dataProxyUrl = `api/plugin-proxy/skyline-forecasting-app/backend_service`;
      
      const response = getBackendSrv().fetch({
        url: dataProxyUrl,
        method: 'POST',
        data: requestBody,
      });

      const result = await lastValueFrom(response);
      
      if (result.status >= 400) {
        throw new Error(`提交失败: ${result.statusText}`);
      }

      // 提交成功后重置表单
      setNewMetricsName('');
      setNewStatement('');
      setShowAddForm(false);
      
      // 重新获取数据以更新表格
      fetchData();
      
      alert('添加成功');
    } catch (error) {
      console.error('提交失败:', error);
      alert(`提交失败: ${error}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <PluginPage>
      <div data-testid={testIds.pageTwo.container}>
        <div style={{ marginBottom: '20px' }}>
          <Button onClick={() => setShowAddForm(!showAddForm)}>
            {showAddForm ? '取消添加' : '添加新指标'}
          </Button>
          
          {showAddForm && (
            <div style={{ marginTop: '15px', padding: '15px', border: '1px solid #ddd', borderRadius: '4px' }}>
              <VerticalGroup spacing="md">
              <HorizontalGroup>
                  <div style={{ width: '150px' }}>datasource:</div>
                  <Select
                    options={dataSources}
                    value={selectedDataSource}
                    onChange={(value) => setSelectedDataSource(value)}
                    placeholder="please select datasource"
                    width={30}
                  />
                </HorizontalGroup>

                <HorizontalGroup>
                  <div style={{ width: '150px' }}>metrics name:</div>
                  <Input
                    value={newMetricsName}
                    onChange={(e) => setNewMetricsName(e.currentTarget.value)}
                    placeholder="please input metrics name"
                    width={30}
                  />
                </HorizontalGroup>
                
                <div style={{ width: '100%' }}>
                  <div style={{ marginBottom: '8px' }}>query statement:</div>
                  <textarea
                    value={newStatement}
                    onChange={(e) => setNewStatement(e.target.value)}
                    placeholder="please input query statement"
                    style={{ 
                      width: '100%', 
                      minHeight: '80px', 
                      padding: '8px',
                      borderRadius: '2px',
                      border: '1px solid #ddd'
                    }}
                  />
                </div>
                
                <Button
                  onClick={handleSubmit}
                  disabled={isSubmitting}
                  variant="primary"
                >
                  {isSubmitting ? 'submit...' : 'submit'}
                </Button>
              </VerticalGroup>
            </div>
          )}
        </div>
        
        {isLoading ? (
          <p>Loading...</p>
        ) : (
          <>
            {Array.isArray(tableData) && tableData.length > 0 ? (
              <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                <thead>
                  <tr>
                    <th style={{ border: '1px solid #ddd', padding: '8px' }}>Metrics Name</th>
                    <th style={{ border: '1px solid #ddd', padding: '8px' }}>Predict Name</th>
                    <th style={{ border: '1px solid #ddd', padding: '8px' }}>Statement</th>
                    <th style={{ border: '1px solid #ddd', padding: '8px' }}>Create Time</th>
                  </tr>
                </thead>
                <tbody>
                  {tableData.map((row, index) => (
                    <tr key={index}>
                      <td style={{ border: '1px solid #ddd', padding: '8px' }}>{row.metrics_name}</td>
                      <td style={{ border: '1px solid #ddd', padding: '8px' }}>{row.predict_name}</td>
                      <td style={{ border: '1px solid #ddd', padding: '8px' }}>{row.statement}</td>
                      <td style={{ border: '1px solid #ddd', padding: '8px' }}>{row.create_time}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            ) : (
              <p>No Data</p>
            )}
          </>
        )}
      </div>
    </PluginPage>
  );
}

export default PageOne;